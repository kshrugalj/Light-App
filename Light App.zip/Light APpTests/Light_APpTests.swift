//
//  Light_APpTests.swift
//  Light APpTests
//
//  Created by Kshrugal Reddy Jangalapalli on 9/26/24.
//

import Testing
@testable import Light_APp

struct Light_APpTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
